<?php

namespace App\Http\Controllers;

use App\Models\Libros;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class LibrosController extends Controller
{
    public function NuevoLibro(Request $request)
    {
        $validacion = Validator::make($request->all(), [
            'nombre_libro'   => 'required|string|max:255',
            'isbn'           => 'required|string|max:50|unique:libros,isbn',
            'editorial'      => 'required|string|max:255',
            'autor'        => 'required|string|max:255',
            'otros_autores'  => 'nullable|string|max:255',
            'cantidad'       => 'required|integer|min:3',
            //'imagen'         => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
        ]);
        if($validacion->fails()){
            return response()->json($validacion->errors(), 400);
        }

        try{

            // Manejar imagen
            // $imagenPath = null;
            // if ($request->hasFile('imagen')) {
            //     $imagenPath = $request->file('imagen')->store('libros', 'public');
            // }

            $libro = Libros::create([
                'nombre_libro' => $request->nombre_libro,
                'isbn'         => $request->isbn,
                'editorial'    => $request->editorial,
                'autor'        => $request->autor,
                'otros_autores'=> $request->otros_autores,
                'cantidad'     => $request->cantidad,
              
            ]);
            $libro->save();

            return response()->json([
                'message' => 'Libro creado exitosamente',
                'data' => $libro
            ], 201);
        }catch(\Exception $e){
            return Response()->json(['error'=> $e->getMessage()], 500);
        }
    }

    public function AgregarImagenLibro(Request $request){
        $this->validate($request,[
            'imagen' => 'required|image',
            'idLibro' => 'required|string',
        ]);

        try{
            //ENSEGUIDA CREAMOS EL NUEVO NOMBRE DE LA IMAGEN Y MOVEMOS
            $nombreImg = $request->idLibro.'_libro.'.$request['imagen']->extension();
            $request->imagen->move(public_path('img_libros'),$nombreImg);

            //ACTUALIZAMOS NOMBRE DE LA IMAGEN
            $libroAgregado = Libros::findOrFail($request->idLibro);
            $libroAgregado->imagen = $nombreImg;
            $libroAgregado->save();

            return Response()->json(['mensaje'=>'Agregado Correctamente'],200);
        }catch(\Exception $e){
            return Response()->json(['error' => $e->getMessage()],500);
        }
        
    }

    public function GetLibros(){ 
        $libros = DB::table('libros')->select('id','nombre_libro','isbn','editorial','autor','otros_autores','cantidad','imagen')->get();

        $librosArray = json_decode(json_encode($libros),true);

        for ($i=0; $i <count($librosArray); $i++) {
            if($librosArray[$i]['otros_autores'] = ! null){
                $librosArray[$i]['autor'] = $librosArray[$i] ['autor'] . '- OTROS:' . $librosArray[$i]['otros_autores'];
            }

            $pathImg = asset('/img_libros/' . $librosArray[$i]['imagen']);
            if($librosArray[$i]['imagen']){
                $librosArray[$i]['imagen'] = '<img width="80" src='.$pathImg.'>';
            }

                $txtHtmlOpciones = '
                <div class="demo-inline-spacing">
                    <button type="button" class="btn btn-icon btn-outline-primary btnEditLibro" onClick="fntEditLibro('.$librosArray[$i]['id'].')">
                        <span class="tf-icons bx bx-edit"></span>
                    </button>
                    <button type="button" class="btn btn-icon btn-outline-secondary btnDelLibro" onClick="fntDelLibro('.$librosArray[$i]['id'].')">
                        <span class="tf-icons bx bx-trash"></span>
                    </button>
                    <button type="button" class="btn rounded-pill btn-icon btn-outline-primary btnStatusLibro" onClick="fntStatusLibro('.$librosArray[$i]['id'].')">
                        <span class="tf-icons bx bx-check"></span>
                    </button>
                </div>
                ';



                $librosArray[$i]['opciones'] = $txtHtmlOpciones;
        }        
         return response()->json(['data'=>$librosArray], 200);
    }

    public function GetLibroId(Request $request){
        $libro = DB::table('libros')->select('id','nombre_libro', 'isbn','editorial','autor', 'otros_autores', 'cantidad', 'imagen')->where('id', $request->idLibro)->first();
        return Response()->json(["data"=>$libro],200);
    }
    
    public function DeleteLibro(Request $request){
        try{
            $libro = Libros::find($request->idLibro);
            $libro->delete();
            return Response()->json(['mensaje'=> 'Eliminado Correctamente', 'icono' => 'success', 'titulo' => 'Enhorabuena!' ], 200);

        }catch(\Exception $e){
            return Response()->json(['mensaje'=> $e->getMenssage(), 'icono' => 'danger', 'titulo' => 'Error!'], 500);
        }

    }


    public function dataLibro(){
            $libros = DB::table('libros')->select('id','nombre_libro','isbn','editorial','autor','otros_autores','cantidad','imagen')->get();

            $librosArray = json_decode(json_encode($libros),true);

            for ($i=0; $i <count($librosArray); $i++) {
                if($librosArray[$i]['otros_autores'] = ! null){
                    $librosArray[$i]['autor'] = $librosArray[$i] ['autor'] . '- OTROS:' . $librosArray[$i]['otros_autores'];
                }
                $pathImg = asset('/img_libros/' . $librosArray[$i]['imagen']);
                if($librosArray[$i]['imagen']){
                    $librosArray[$i]['imagen'] = '<img width="80" src='.$pathImg.'>';
                }

                $txtHtmlOpciones = '
                <div class="demo-inline-spacing">
                    <button type="button" class="btn btn-icon btn-outline-primary btnEditLibro" <="fntEditLibro('.$librosArray[$i]['id'].')">
                        <span class="tf-icons bx bx-edit"></span>
                    </button>

                    <button type="button" class="btn btn-icon btn-outline-secondary btnDelLibro" onClick="fntDelLibro('.$librosArray[$i]['id'].')">
                        <span class="tf-icons bx bx-trash"></span>
                    </button>

                    <button type="button" class="btn rounded-pill btn-icon btn-outline-primary btnStatusLibro" onClick="fntStatusLibro('.$librosArray[$i]['id'].')">
                        <span class="tf-icons bx bx-check"></span>
                    </button>
                </div>
                ';

            $librosArray[$i]['opciones'] = $txtHtmlOpciones;
        }

        return response()->json(['data'=>$librosArray], 200);
    }


    public function ActualizarLibro(Request $request){
        $validacion = Validator::make($request->all(), [
            'nombre_libro'  =>  'required|string|max:255',
            'isbn'          =>  'required|string|max:50|unique:libros,isbn',
            'editorial'     =>  'required|string|max:255',
            'autor'         =>  'required|string|max:255',
            'otros_autores' =>  'nullable|string|max:255',
            'cantidad'      =>  'required|integer|min:3',
            // 'imagen'        =>'required|image|mimes:jpg,jpeg,png|max:2048',
        ]);
        if($validacion->fails()){
            return response()->json($validacion->errors(), 400);

        }
         
        try{
            $libroActualizar = Libros::findOrFail($request->idLibro);
            $libroActualizar->nombre_libro = $request->nombre_libro;
            $libroActualizar->isbn = $request->isbn;
            $libroActualizar->editorial = $request->editorial;
            $libroActualizar->autor = $request->autor;
            $libroActualizar->otros_autores = $request ->otros_autores;
            $libroActualizar->cantidad =$request ->cantidad;
            $libroActualizar->save();

            return Response()->json(['message'=>'Actualizar Correctamente', 'id'=>$libroActualizar->id], 200);
        }catch(Exception $e){
            
            return Response()->json(['error'=> $e->getMessage()], 500);
        }
    }


}
        

//public function DeleteLibro(Request $request){
 
