@extends('layaout')

@section('content_body')
    Catálogo de alumnos
@endsection


@section('content_script')
    
@endsection