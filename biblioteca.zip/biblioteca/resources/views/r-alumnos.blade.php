@extends('layaout')

@section('content_body')
    Reportes alumnos
@endsection


@section('content_script')
    
@endsection