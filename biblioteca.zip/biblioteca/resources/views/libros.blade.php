@extends('layaout')

@section('content_body')
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Catálogo /</span> Libros</h4>


    <!-- MODAL LIBROS -->  
    <div class="modal fade" id="modalLibros" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel3">Formulario Libros</h5>
                    <button type="button" id="cerrarModalLibros" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form enctype="multipart/form-data" id="formularioLibros" class="needs-validation" novalidate>...
                    {{ csrf_field() }}
                <div class="modal-body">
                    <div class="row">
                        <input type="hidden" id="idLibro" name="idLibro">
                        <div class="col mb-3">
                            <label for="nombre_libro" class="form-label">NOMBRE DEL LIBRO</label>
                            <input type="text" id="nombre_libro" name="nombre_libro" class="form-control" placeholder="Nombre del Libro" required/>
                        </div>
                    </div>
                    <div class="row g-2">
                        <div class="col mb-0">
                            <label for="isbn" class="form-label">ISBN</label>
                            <input type="text" id="isbn" name="isbn" class="form-control" placeholder="ISBN" />
                        </div>
                        <div class="col mb-0">
                            <label for="editorial" class="form-label">EDITORIAL</label>
                            <input type="text" id="editorial" name="editorial" class="form-control" placeholder="Editorial" />
                        </div>
                    </div>
                    <div class="row g-2">
                        <div class="col mb-0">
                            <label for="autor" class="form-label">AUTOR PRINCIPAL</label>
                            <input type="text" id="autor" name="autor" class="form-control" placeholder="Autor" />
                        </div>
                        <div class="col mb-0">
                            <label for="otros_autores" class="form-label">OTROS AUTORES</label>
                            <textarea class="form-control" name="otros_autores" id="otros_autores" cols="30" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="row g-2">
                        <div class="col mb-0">
                            <label for="cantidad" class="form-label">CANTIDAD</label>
                            <input type="number" id="cantidad" name="cantidad" class="form-control" />
                        </div>
                        
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Cerrar
                    </button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>
        </div>  
    </div>
</div>




    {{-- TABLA --}}
    <div class="card">
        <div class="card-header">
            <strong>Nuevo Libro</strong>
            <button type="button" class="btn btn-icon btn-primary" data-bs-toggle="modal" data-bs-target="#modalLibros">
                <span class="tf-icons bx bx-plus"></span>
            </button>

        </div>
        <div class="table-responsive text-nowrap px-4">
            <table id="tablaLibro" class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>NOMBRE</th>
                        <th>ISBN</th>
                        <th>EDITORIAL</th>
                        <th>AUTOR (S)</th>
                        <th>CANTIDAD</th>
                        <th>IMAGEN</th>
                        <th>OPCIONES</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    
                </tbody>
            </table>
        </div>
    </div>
@endsection




@section('content_script')
    <script>

        var table;
        $(document).ready(function(){
            table = $('#tablaLibro').DataTable( {
                //"processing": true,
                //"srverSide": true,
                "ajax": "/api/dataLibro",
                "columns": [ {
                    "data":"id"
                },
                {   "data":"nombre_libro"

                },
                {   "data":"isbn"

                },
                {   "data":"editorial"

                },
                {   "data":"autor"

                },
                {   "data":"cantidad"

                },
                {   "data":"imagen"

                },
                {   "data":"opciones"

                    }
                ]
            } );

         //table.ajax.reload();
        } );
        //new DataTable('#');


        //AGREGAR NUEVO LIBRO
        const form = document.querySelector('#formularioLibros');
        form.addEventListener('submit', event =>{
            console.log('submit')
            event.preventDefault()
            if (!form.checkValidity()) {
                event.stopPropagation()
            } else {
                var datos=$('#formularioLibros').serialize()
                let existeRegistro = $('#idLibro').val()
                let url_envio = "http://127.0.0.1:8000/api/nuevoLibro"
                let metodo_envio = "POST"
                if (existeRegistro  != "") {
                  url_envio = "http://127.0.0.1:8000/api/actualizarLibro"
                  metodo_envio = "PUT"  
                }
                console.log('id es: ',existeRegistro)
                $.ajax({
                    type: metodo_envio,
                    url: url_envio,
                    data: datos,
                    dataType: 'json',
                    success: function(data){
                        console.log(data.message)
                        $('#idLibro').val("")
                        $('#cerrarModalLibros').click();
                        $('#formularioLibros').trigger('reset')
                        Swal.fire({
                            icon: 'success',
                            title: 'Enhorabuena',
                            html: data.message,
    
                        }).then(async () => {
                            //await cargarDatosProductos()
                            await table.ajax.reload();
                            CargarImagenProducto(data.data.id)

                        })
                    },
                        error: function(xhr, status) {
                            $('#cerrarModalLibros').click();
                            respuesta = xhr.responseJSON;
                            informacionError = "";
                            for (const [key, value] of Object.entries(respuesta)) {
                                informacionError += `${key}: ${value} <br>`;
                            }
                            Swal.fire({
                                icon: 'error',
                                title: 'oooops',
                                html: informacionError,
                            })

                        }
                })
            }

            form.classList.add ('was-validated')

        },false)

        //AGREGAR DATOS
        async function CargarImagenProducto(idLibro){
            const {
                value: file
            }= await Swal.fire({
                title: '¿Cargar Imagen del Libro?',
                input: 'file',
                inputAttributes: {
                    'accept': 'image/+',
                    'aria-label': 'Upload your profile picture'

                }
            })
            if (file){
                let dataImagen = new FormData();
                dataImagen.append('_token','{{ csrf_token() }}');
                dataImagen.append('imagen', file);
                dataImagen.append('idLibro',idLibro);
                $.ajax({
                    type: 'POST',
                    url: 'http://127.0.0.1:8000/api/agregarImagenLibro',
                    data: dataImagen,
                    //dataType: 'json'
                    processData: false,
                    contentType: false,
                    success: function(data) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Enhorabuena',
                            html: data.mensaje,
                        })
                        table.ajax.reload();
                    },
                    error: function(xhr, status) {
                        respuesta = xhr.responseJSON;
                        informacionError = "";
                        for (const[key, value] of Object.entries(respuesta)) {
                            informacionError += `${key}: ${value} <br>`;
                        }

                        Swal.fire({
                            icon: 'error',
                            title: 'oooops',
                            html: informacionError,
                        })
                    }
                })
            }

        }

        //ELIMINAR LIBRO
        function fntDelLibro (idLibro) {
            Swal.fire({
                title: "Eliminar libro",
                text:"Seguro que deseas eliminar el libro?",
                icon:"warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Si, Eliminar!"
            }).then((result) => {
                if(result.isConfirmed){
                    fetch('http://127.0.0.1:8000/api/eliminarLibro',{
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({idLibro: idLibro})
                    })
                    .then(response => response.json())
                    .then((data)=>{
                        if(data.icono = 'success'){
                            table.ajax.reload();
                        }
                        Swal.fire({
                            title: data.titulo,
                            text: data.mensaje,
                            icon: data.icono
                        });
                    })
                }
            })
        }

        function fntEditLibro(idLibro){
            console.log(idLibro)

            fetch('http://127.0.0.1:8000/api/dataLibroId',{
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({idLibro})
            })
            .then(response => response.json())
            .then((data)=>{
                console.log(data.data);
                $("#idLibro").val(data.data.id);
                $("#nombre_libro").val(data.data.nombre_libro);
                $("#isbn"). val(data.data.isbn);
                $("#editorial").val(data.data.editorial);
                $("#autor").val(data.data.autor);
                $("#otros_autores").val(data.data.otros_autores);
                $("#cantidad").val(data.data.cantidad);

                $("#modalLibros").modal("show");

            })
        }
        </script>
@endsection 