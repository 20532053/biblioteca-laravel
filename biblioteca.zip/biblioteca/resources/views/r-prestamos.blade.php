@extends('layaout')

@section('content_body')
    Reportes prestamos
@endsection


@section('content_script')
    
@endsection