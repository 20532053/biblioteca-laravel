<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('layaout');
});

Route::get('/libros', function () {
    return view('libros');
});

Route::get('/categorias', function () {
    return view('categorias');
});

Route::get('/alumnos', function () {
    return view('alumnos');
});

Route::get('/r-prestamos', function () {
    return view('r-prestamos');
});

Route::get('/r-alumnos', function () {
    return view('r-alumnos');
});