<?php

use App\Http\Controllers\LibrosController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


Route::post('/nuevoLibro', [LibrosController::class, 'NuevoLibro']);
Route::post('/agregarImagenLibro', [LibrosController::class, 'AgregarImagenLibro']);
Route::get('/dataLibro', [LibrosController::class, 'GetLibros']);
Route::post('/dataLibroId', [LibrosController::class, 'GetLibroId']);
Route::post('/eliminarLibro', [LibrosController::class, 'DeleteLibro']);
Route::put('/actualizarLibro', [LibrosController::class, 'ActualizarLibro']);
