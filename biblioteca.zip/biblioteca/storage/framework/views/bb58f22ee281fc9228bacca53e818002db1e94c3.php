

<?php $__env->startSection('content_body'); ?>
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Catálogo /</span> Libros</h4>



    


    <!-- MODAL LIBROS -->
    <div class="modal fade" id="modalLibros" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel3">Formulario Libros</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col mb-3">
                            <label for="nameLarge" class="form-label">NOMBRE DEL LIBRO</label>
                            <input type="text" id="nameLarge" class="form-control" placeholder="Nombre del Libro" />
                        </div>
                    </div>
                    <div class="row g-2">
                        <div class="col mb-0">
                            <label for="emailLarge" class="form-label">ISBN</label>
                            <input type="text" id="emailLarge" class="form-control" placeholder="ISBN" />
                        </div>
                        <div class="col mb-0">
                            <label for="dobLarge" class="form-label">EDITORIAL</label>
                            <input type="text" id="dobLarge" class="form-control" placeholder="Editorial" />
                        </div>
                    </div>
                    <div class="row g-2">
                        <div class="col mb-0">
                            <label for="emailLarge" class="form-label">AUTOR PRINCIPAL</label>
                            <input type="text" id="emailLarge" class="form-control" placeholder="Autor" />
                        </div>
                        <div class="col mb-0">
                            <label for="dobLarge" class="form-label">OTROS AUTORES</label>
                            <textarea class="form-control" name="autores" id="autores" cols="30" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="row g-2">
                        <div class="col mb-0">
                            <label for="emailLarge" class="form-label">CANTIDAD</label>
                            <input type="number" id="emailLarge" class="form-control" />
                        </div>
                        <div class="col mb-0">
                            <label for="dobLarge" class="form-label">IMAGEN</label>
                            <input class="form-control" type="file" id="formFile">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Close
                    </button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>




    
    <div class="card">
        <div class="card-header">
            <strong>Nuevo Libro</strong>
            <button type="button" class="btn btn-icon btn-primary" data-bs-toggle="modal" data-bs-target="#modalLibros">
                <span class="tf-icons bx bx-plus"></span>
            </button>

        </div>
        <div class="table-responsive text-nowrap">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>NOMBRE</th>
                        <th>EDITORIAL</th>
                        <th>AUTOR (S)</th>
                        <th>CANTIDAD</th>
                        <th>IMAGEN</th>
                        <th>OPCIONES</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <tr>
                        <td>1</td>
                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>Angular Project</strong></td>
                        <td>Editoria</td>
                        <td>Autores
                            <ul class="list-unstyled users-list m-0 avatar-group d-flex align-items-center">
                                <li data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top"
                                    class="avatar avatar-xs pull-up" title="" data-bs-original-title="Lilian Fuller">
                                    <img src="../assets/img/avatars/5.png" alt="Avatar" class="rounded-circle">
                                </li>
                                <li data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top"
                                    class="avatar avatar-xs pull-up" title=""
                                    data-bs-original-title="Sophia Wilkerson">
                                    <img src="../assets/img/avatars/6.png" alt="Avatar" class="rounded-circle">
                                </li>
                                <li data-bs-toggle="tooltip" data-popup="tooltip-custom" data-bs-placement="top"
                                    class="avatar avatar-xs pull-up" title=""
                                    data-bs-original-title="Christina Parker">
                                    <img src="../assets/img/avatars/7.png" alt="Avatar" class="rounded-circle">
                                </li>
                            </ul>
                        </td>
                        <td><span class="badge bg-label-primary me-1">3</span></td>
                        <td>Imagen</td>
                        <td>
                            <div class="demo-inline-spacing">
                                <button type="button" class="btn btn-icon btn-outline-primary">
                                    <span class="tf-icons bx bx-edit"></span>
                                </button>
                                <button type="button" class="btn btn-icon btn-outline-secondary">
                                    <span class="tf-icons bx bx-trash"></span>
                                </button>
                                <button type="button" class="btn rounded-pill btn-icon btn-outline-primary">
                                    <span class="tf-icons bx bx-check"></span>
                                </button>
                            </div>
                        </td>
                    </tr>

                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content_script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layaout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\edgar\Documents\PROYECTOS LARAVEL\biblioteca\resources\views/libros.blade.php ENDPATH**/ ?>