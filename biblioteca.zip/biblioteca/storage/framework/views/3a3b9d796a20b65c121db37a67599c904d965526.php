

<?php $__env->startSection('content_body'); ?>
    Reportes alumnos
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content_script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layaout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Erica\Documents\Laravel\biblioteca\resources\views/r-alumnos.blade.php ENDPATH**/ ?>