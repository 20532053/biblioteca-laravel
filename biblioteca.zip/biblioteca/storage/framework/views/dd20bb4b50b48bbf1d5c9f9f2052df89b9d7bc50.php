

<?php $__env->startSection('content_body'); ?>
    Catálogo de alumnos
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content_script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layaout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Eduardo0\Documents\Laravel\biblioteca\resources\views/alumnos.blade.php ENDPATH**/ ?>